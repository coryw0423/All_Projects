/*
 * File: StringLogger.java
 * Author: Max Hibbard maxwellh@uab.edu
 * Assignment:  P5 - EE333 Spring 2020
 * Vers: 1.0.1 03/11/2020 wmh - initial coding
 */

package edu.uab.maxwellh.p5;

import java.util.ArrayList;

/**
 * A ECardLogger which logs the strings to a string array that can be retrieved.
 * @author maxwellh
 */
public class StringLogger implements ECardLogger {
  
  private ArrayList<String> entries;

  /**
   * Create a StringLogger.
   */
  public StringLogger() {
    entries = new ArrayList<>();
  }
  
  /**
   * Create a log entry.
   * @param blazerID user code
   * @param message text
   */
  @Override
  public void log(String blazerID, String message) {
    entries.add(blazerID + ": " + message);
  }
  
  /**
   * Return an array matching content and reset log.
   * @return an array containing the strings written.
   */
  public Object[] extractLog() {
    Object[] log = entries.toArray();
    entries.clear();
    return log;
  }
  
}
